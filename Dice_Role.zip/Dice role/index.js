// *****************--------------------------another method----------------------*************

// for left Dice 
//var randomNumber1 = Math.floor(Math.random()*7);
// var randomDiceImage1 = "dice" +randomNumber1+ ".png";  //random dice img from "dice1.png" to "dice6.png"
// var randomImageSource1 = "images/" + randomDiceImage1; // img source "images/dice1.png" to "images/dice6.png"
// document.getElementById("d1").setAttribute("src", randomImageSource1);
// 
// 
// for right Dice 
// var randomNumber2 = Math.floor(Math.random()*7);
// var randomDiceImage2 = "dice" +randomNumber2+ ".png"; 
// var randomImageSource2 = "images/" + randomDiceImage2;
// document.getElementById("d2").setAttribute("src", randomImageSource2);


// *****************--------------------------another method----------------------*************



var dice1Array = new Array("images/dice1.png","images/dice2.png","images/dice3.png" , "images/dice4.png" , "images/dice5.png" , "images/dice6.png");

// // for Dice 1

var randomNumber1=Math.floor(Math.random() * dice1Array.length) ;
document.getElementById("d1").src = dice1Array[randomNumber1];

// // for Dice 2

var dice2Array = new Array("images/dice1.png","images/dice2.png","images/dice3.png" , "images/dice4.png" , "images/dice5.png" , "images/dice6.png");
var randomNumber2=Math.floor(Math.random() * dice2Array.length) ;
document.getElementById("d2").src = dice2Array[randomNumber2];






// for winning

if(randomNumber1>randomNumber2){
    document.querySelector("h1").innerHTML="🚩Player 1 is wins";
}else if(randomNumber1<randomNumber2){
    document.querySelector("h1").innerHTML="Player 2 is wins🚩";
}else{
    document.querySelector("h1").innerHTML="Draw!";
}